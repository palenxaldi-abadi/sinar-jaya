# Sinar Jaya

Website statis berbasis HTML, CSS, dan JavaScript untuk dipublikasikan melalui GitHub Pages.

## Cara hosting dari HP

1. Unduh dan ekstrak `sinar-jaya-github.zip`.
2. Buka GitHub dan buat repository baru, misalnya `sinar-jaya`.
3. Unggah file `index.html`, `.nojekyll`, dan `README.md` ke bagian utama (root) repository — jangan taruh `index.html` di dalam folder lain.
4. Buka **Settings → Pages**.
5. Pada **Build and deployment**, pilih **Deploy from a branch**.
6. Pilih branch `main` dan folder `/(root)`, lalu tekan **Save**.
7. Tunggu proses publikasi selesai. GitHub akan menampilkan alamat website di bagian Pages.

## Catatan penting

- Logo yang ada pada halaman saat ini sudah tertanam di dalam `index.html`, sehingga tidak perlu file gambar terpisah.
- Ini adalah aplikasi demo statis. Data yang disimpan di browser tidak otomatis tersinkron ke perangkat lain dan tidak cocok untuk menyimpan data keuangan atau kata sandi sungguhan.
- Fitur chat lintas perangkat, akun sungguhan, serta deposit/penarikan uang nyata membutuhkan backend dan database yang aman. Jangan gunakan data atau uang sungguhan pada versi statis ini.
